# Beginners-javascript-projects
Some javascript projects that you can build as beginners.


### API key for Weather prognosis app:

  To get an api key for Weather prognosis app you can go to https://www.weatherapi.com website and create an account.
